package com.learning.springws;

import java.util.Date;

public interface HumanResourceService {

    void bookHoliday(Date startDate, Date endDate, String name);

}

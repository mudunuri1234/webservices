package com.learning.javaee.dvo;

/**
 * Created by IntelliJ IDEA.
 * User: asmudun
 * Date: Jul 24, 2009
 * Time: 10:47:03 AM
 */
public class User {

    private String userName;
    private String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}

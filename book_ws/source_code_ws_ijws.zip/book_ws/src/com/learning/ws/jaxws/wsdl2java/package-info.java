@javax.xml.bind.annotation.XmlSchema(namespace = "http://jaxws.ws.learning.com/")
package com.learning.ws.jaxws.wsdl2java;

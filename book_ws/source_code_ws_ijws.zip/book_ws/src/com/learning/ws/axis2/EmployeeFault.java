package com.learning.ws.axis2;

public class EmployeeFault extends java.lang.Exception {

    public static final long serialVersionUID = 12324835835L;

    public EmployeeFault() {
        super();
    }

    public EmployeeFault(String message) {
        super(message);
    }

    public EmployeeFault(String message, Throwable cause) {
        super(message, cause);
    }

    public void setNil() {

    }

}

package com.learning.ws.jaxp;

/**
 * Created by IntelliJ IDEA.
 * User: Srinivas
 * Date: Nov 1, 2008
 * Time: 10:47:13 AM
 */
public class Student {
    private String id;
    private String firstName;
    private String lastName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }




}
